import os
import json
import psycopg2

def lambda_handler(event, context):
    db_host = os.environ['DB_HOST']
    db_port = int(os.environ.get('DB_PORT', 5432))
    db_username = os.environ['DB_USERNAME']
    db_password = os.environ['DB_PASSWORD']
    target_db = os.environ['TARGET_DB']

    try:
        # Connect to the default 'postgres' database to perform the drop
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            user=db_username,
            password=db_password,
            dbname='postgres'
        )
        conn.autocommit = True
        cursor = conn.cursor()

        # Drop the target database
        drop_db_query = f"DROP DATABASE IF EXISTS {target_db};"
        cursor.execute(drop_db_query)
        
        # Recreate the database
        create_db_query = f"CREATE DATABASE {target_db};"
        cursor.execute(create_db_query)
        
        # Use the database
        use_db_query = f"USE {target_db};"
        cursor.execute(use_db_query)

        # Close the connection
        cursor.close()
        conn.close()

        return {
            'statusCode': 200,
            'body': json.dumps(f"Database '{target_db}' dropped successfully.")
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error dropping database: {str(e)}")
        }
